/*
 * Authentication and signup codez
 */

function dosignup() {
    $('#errorbase').hide();
    $('#signupBtn').html('<i class="fa fa-cog fa-spin"></i> Please wait...');
    $('#signupBtn').attr('disabled', true);
    if ($('#usernameBox').val() === "") {
        $('#errormsg').text("Error:  Missing username.");
        $('#errorbase').css('display', 'block');
        $('#signupBtn').html('<i class="fa fa-user-plus"></i> Sign Up');
        $('#signupBtn').attr('disabled', false);
        return;
    }
    if ($('#passwordBox').val() !== $('#passwordBox2').val()) {
        $('#errormsg').text("Error:  Passwords do not match.");
        $('#errorbase').css('display', 'block');
        $('#signupBtn').html('<i class="fa fa-user-plus"></i> Sign Up');
        $('#signupBtn').attr('disabled', false);
        return;
    }
    $.post("https://sso.netsyms.com/api/adduser.php",
            {
                user: $('#usernameBox').val(),
                pass: $('#passwordBox').val(),
                name: $('#nameBox').val(),
                email: $('#emailBox').val()
            },
    function (data) {
        if (data === 'OK') {
            username = $('#usernameBox').val();
            password = $('#passwordBox').val();
            localStorage.setItem("username", username);
            localStorage.setItem("password", password);
            openscreen("home");
        } else {
            $('#signupBtn').html('<i class="fa fa-user-plus"></i> Sign Up');
            $('#signupBtn').attr('disabled', false);
            $('#errormsg').text("Error: " + data);
            $('#errorbase').css('display', 'block');
        }
    }).fail(function () {
        $('#signupBtn').html('<i class="fa fa-user-plus"></i> Sign Up');
        $('#signupBtn').attr('disabled', false);
        $('#errormsg').text("Error: Network failure.");
        $('#errorbase').css('display', 'block');
    });
}

function dologin() {
    $('#errorbase').hide();
    $('#loginBtn').html('<i class="fa fa-cog fa-spin"></i> Logging in...');
    $('#loginBtn').attr('disabled', true);
    if ($('#usernameBox').val() === "") {
        $('#errormsg').text("Error:  Missing username.");
        $('#errorbase').css('display', 'block');
        $('#loginBtn').html('<i class="fa fa-sign-in"></i> Login');
        $('#loginBtn').attr('disabled', false);
        return;
    }
    $.post("https://sso.netsyms.com/api/simpleauth.php",
            {user: $('#usernameBox').val(), pass: $('#passwordBox').val()},
    function (data) {
        if (data === 'OK') {
            username = $('#usernameBox').val();
            password = $('#passwordBox').val();
            localStorage.setItem("username", username);
            openscreen("home");
        } else {
            $('#loginBtn').html('<i class="fa fa-sign-in"></i> Login');
            $('#loginBtn').attr('disabled', false);
            $('#errormsg').text(data);
            $('#errorbase').css('display', 'block');
        }
    }).fail(function () {
        $('#loginBtn').html('<i class="fa fa-sign-in"></i> Login');
        $('#loginBtn').attr('disabled', false);
        $('#errormsg').text("Error: Network failure.");
        $('#errorbase').css('display', 'block');
    });
}

