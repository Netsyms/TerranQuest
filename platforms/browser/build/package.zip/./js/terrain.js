/**
 * Handles GPS and terrain data.
 */

var latitude = 0.0000;
var longitude = 0.0000;
var lastgpstime = 0;
var gpsaccuracy = 9999;
var terraintypeid = 0;


var onSuccess = function (position) {
    latitude = position.coords.latitude;
    longitude = position.coords.longitude;
    lastgpstime = position.timestamp;
    gpsaccuracy = position.coords.accuracy;
    var rasterurl = "http://earth.apis.netsyms.net/terrain.php?format=json&lat="
            + latitude + "&long=" + longitude;
    $.get(rasterurl, function (data) {
        if (data.status === 'OK') {
            terraintypeid = data.typeid;
        }
        //position.coords.altitude
        //position.coords.altitudeAccuracy
        //position.coords.heading
        //position.coords.speed
    }, "json");
};


function onError(error) {
    $('#coords').html('Error: \nCode: ' + error.code
            + '\n' + 'Message: ' + error.message);
}

setInterval(function () {
    navigator.geolocation.getCurrentPosition(onSuccess, onError)
}, 5000);